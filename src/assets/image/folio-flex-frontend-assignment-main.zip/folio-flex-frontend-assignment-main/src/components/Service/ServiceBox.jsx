import React from "react";

const ServiceBox = ({ children }) => {
  return <div className="service-box wow fadeInUp">{children}</div>;
};

export default ServiceBox;
